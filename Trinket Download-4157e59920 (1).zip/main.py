# foodcourt order
order=['burger','sandwich','pizza']
print('welcome our food court🙏')
price_details={'burger':400,'sandwich':220,'pizza':1000}
print(price_details)
details=input('which food do you want order:\nburger,\nsandwich,\npizza\n')
print('please pay your bill')
print('\nplease wait for you order')
if details in order[0]:
  print('\nTake your burger')
elif details in order[1]:
  print('\nTake your sandwich') 
elif details in order[2]:
  print('\nTake your pizza')
else:
  print('invalid item')
  
  
  
  
  